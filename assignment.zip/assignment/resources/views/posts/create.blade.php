<!-- resources/views/posts/create.blade.php -->

@extends('layouts.app')

@section('content')
    <h1>Create New Post</h1>

    <form action="{{ route('posts.store') }}" method="post">
        @csrf

        <label for="title">Title:</label>
        <input type="text" name="title" id="title" value="{{ old('title') }}" required>
        @error('title')
            <div>{{ $message }}</div>
        @enderror

        <label for="content">Content:</label>
        <textarea name="content" id="content" required>{{ old('content') }}</textarea>
        @error('content')
            <div>{{ $message }}</div>
        @enderror

        <button type="submit">Create Post</button>
    </form>
@endsection
